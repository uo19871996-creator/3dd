# Motion System Reference

Use this reference to choreograph animation like a premium studio website.

## Timing

- Hero object entrance: 1.0s to 1.4s
- Hero text entrance: 0.8s to 1.1s
- Text stagger: 0.04s to 0.12s
- Card reveal: 0.5s to 0.8s
- Section transition: 0.8s to 1.2s
- CTA hover: 120ms to 280ms

## Easing

- Use expo.out for cinematic reveals.
- Use power3.out for UI entrance.
- Use power2.inOut for camera and object transitions.
- Use scrubbed timelines for scroll-linked stories.

## Scroll choreography

A strong scroll sequence often follows this pattern:

1. Hero object drifts slowly while text appears.
2. Camera moves closer as the user scrolls.
3. Object rotates or transforms while feature cards enter.
4. Background depth shifts with parallax.
5. Final CTA resolves the story and reduces motion.

## Reduced motion

Always include a reduced-motion mode:
- Disable scroll-scrubbed camera choreography.
- Keep static 3D scene or fallback image.
- Remove continuous rotation where it may distract.
- Preserve content and CTA clarity.
