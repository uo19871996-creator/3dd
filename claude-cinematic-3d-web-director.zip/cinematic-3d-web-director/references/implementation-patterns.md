# Implementation Patterns Reference

Use this reference when writing code for animated 3D websites.

## Recommended stack

- React + TypeScript
- Vite or Next.js
- Three.js
- React Three Fiber
- @react-three/drei
- @react-three/postprocessing
- GSAP and ScrollTrigger
- Tailwind CSS or CSS modules

## Project structure

Prefer this structure:

src/
  app or pages/
  components/
    Hero.tsx
    Scene.tsx
    sections/
  three/
    HeroScene.tsx
    Materials.tsx
    CameraRig.tsx
  hooks/
    useReducedMotion.ts
  styles/

## Performance checklist

- Use Canvas dpr between 1 and 2.
- Lazy-load heavy 3D scenes.
- Use Suspense and a loading state.
- Avoid excessive particle counts.
- Use compressed models when provided.
- Do not use postprocessing heavily on mobile.
- Use mobile fallbacks when the scene is expensive.
- Do not animate layout properties when transforms work.

## WebGL fallback

When no 3D model is provided, create premium placeholder geometry:
- Torus knot with glass material
- Layered orbital rings
- Particle field
- Abstract crystal object
- Floating interface panels

Do not ask the user for a model unless the task specifically depends on an exact product model.

## GSAP pattern

Use GSAP for timeline-based cinematic reveals and ScrollTrigger for scroll-linked movement. Register plugins once. Clean up timelines in React effects.

## React Three Fiber pattern

Separate UI and Canvas concerns:
- DOM sections stay in standard React components.
- 3D scene stays in Scene or HeroScene components.
- Camera movement goes in a CameraRig component.
- Materials and geometry are reusable components.
