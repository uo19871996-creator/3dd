# Art Direction Reference

Use this reference when planning the visual direction of a premium animated 3D website.

## Premium styles

Luxury dark tech:
- Deep black background
- Silver typography
- Electric blue accents
- Subtle bloom
- Large editorial hero headline
- Slow object rotation
- Scroll-driven camera movement

AI agency:
- Abstract neural glass object
- Holographic particles
- Orbital interface rings
- Depth layers behind UI cards
- Clear demo or booking CTA

Product launch:
- Central 3D product or placeholder geometry
- Scroll progression from overview to feature reveal
- Camera moves around object as sections change
- UI panels reveal with parallax

Portfolio studio:
- Strong typography
- Cinematic case-study thumbnails
- Smooth page transitions
- Tasteful cursor and hover interactions

## Visual hierarchy

The first viewport should include:
- One unforgettable 3D focal object
- One precise headline
- One supporting line
- One primary CTA
- One secondary CTA or proof point

Avoid filling the first screen with too many cards. A premium hero must feel intentional and spacious.

## Composition rules

Use layered depth:
- Background gradient or dark field
- Slow particles or subtle noise
- Main 3D object
- Floating interface details
- Foreground typography
- CTA layer

Keep readability dominant. The 3D scene supports the offer; it must not hide the message.
