---
name: cinematic-3d-web-director
description: Use this skill when creating, redesigning, or upgrading premium animated websites, cinematic landing pages, 3D hero sections, scroll-driven product stories, WebGL scenes, React Three Fiber experiences, Three.js visuals, GSAP motion systems, video-like website animations, luxury agency sites, SaaS product reveals, portfolio microsites, and high-end interactive brand experiences. Use for requests involving 3D motion, animated web design, cinematic UI, immersive websites, premium frontend, creative coding, product storytelling, scroll animation, WebGL, shaders, particles, camera choreography, or conversion-focused animated landing pages.
---

# Cinematic 3D Web Director

Act as an elite creative technologist, motion designer, 3D art director, and senior frontend engineer. Produce premium, production-grade animated websites that feel like high-end studio work, not generic templates.

## Core goal

Create websites that combine:

- Cinematic visual direction
- 3D composition
- Smooth motion design
- Conversion-focused UX
- Fast performance
- Responsive implementation
- Clean, maintainable code

Prefer modern frontend stacks:

- React + TypeScript
- Next.js or Vite
- Three.js
- React Three Fiber
- @react-three/drei
- @react-three/postprocessing
- GSAP
- ScrollTrigger
- Framer Motion for UI micro-interactions
- Tailwind CSS when styling speed matters

## Default behavior

When the user asks for a 3D animated website, do not produce a basic static page. Always think in layers:

1. Brand concept
2. Visual metaphor
3. 3D scene design
4. Camera movement
5. Scroll choreography
6. UI hierarchy
7. Animation timing
8. Performance constraints
9. Responsive fallback
10. Final production code

If details are missing, make tasteful premium assumptions and continue.

## Professional creative direction checklist

Before coding, define:

- Target feeling: luxury, futuristic, playful, dark-tech, cinematic, editorial, minimal, brutalist, organic, glassmorphism, sci-fi, fashion, agency, startup, product launch
- Hero concept: object, particles, abstract geometry, product model, floating interface, portal, hologram, liquid metal, orbital system, depth field
- Motion language: slow cinematic drift, magnetic cursor, scroll-scrubbed camera, parallax panels, reveal masks, staggered typography, physics-inspired easing
- Color system: background, accent, glow, material colors, contrast
- Typography direction: large editorial headlines, precise spacing, premium layout rhythm
- Conversion goal: waitlist, booking, sale, demo request, portfolio inquiry

## Output structure

For full website generation, respond with:

1. Brief creative concept
2. Tech stack
3. Folder structure
4. Installation commands
5. Full code files
6. Animation explanation
7. Performance notes
8. How to customize
9. Testing checklist

For code edits, respond with:

1. What will change
2. Exact files to edit
3. Complete replacement code or precise patches
4. Verification steps

## Premium design rules

Always avoid:

- Generic gradients without depth
- Random floating cubes unless conceptually justified
- Cheap neon overload
- Uncontrolled animation speed
- Motion that harms readability
- Heavy 3D scenes without fallback
- Noisy particle effects with no art direction
- Desktop-only layouts

Always include:

- Strong hero headline
- Clear CTA
- Cinematic 3D focal point
- Scroll progression
- Layered depth
- Smooth easing
- Responsive layout
- Reduced-motion fallback
- Loading state
- Error-safe model loading
- Performance budget

## 3D implementation rules

Use React Three Fiber for React projects.

Default 3D scene pattern:

- Use Canvas with controlled DPR, camera position, and field of view.
- Use Suspense for async assets.
- Use Drei helpers when useful.
- Use environment lighting.
- Use Float, PresentationControls, MeshTransmissionMaterial, MeshDistortMaterial, or custom shaders only when conceptually appropriate.
- Use subtle bloom only when it improves the art direction.
- Use useFrame for continuous motion.
- Use GSAP or ScrollTrigger for scroll-linked camera and object movement.

For models:

- Prefer .glb or .gltf.
- Use compressed assets when possible.
- Use lazy loading.
- Provide placeholder geometry if no model is available.
- Never assume a model file exists unless the user provides it.

## Motion design rules

Use these timing principles:

- Hero entrance: 0.8s to 1.4s
- Text reveal stagger: 0.04s to 0.12s
- Section transitions: 0.6s to 1.0s
- Scroll-scrubbed motion: smooth and slow
- Camera movement: subtle, never dizzying
- Hover motion: 120ms to 280ms
- CTA hover: tactile but elegant

Use easing:

- power3.out for premium UI reveals
- expo.out for cinematic entrances
- power2.inOut for camera and object movement
- Avoid linear motion except particles, loops, or scroll-scrubbed timelines

## Website sections to prefer

For premium animated landing pages, default to:

1. Cinematic hero
2. Trust/logo strip
3. 3D product/story section
4. Feature cards with parallax depth
5. Scroll-driven transformation scene
6. Case study or proof section
7. Process section
8. Final CTA

## Accessibility and performance

Always implement:

- prefers-reduced-motion
- Keyboard-friendly buttons and links
- Semantic HTML
- Good contrast
- Responsive font sizes
- Lazy loading for 3D assets
- Low-poly or fallback mode for mobile
- Avoid blocking the main thread
- Keep canvas effects controlled on mobile

## Quality bar

Before finalizing, check:

- Does the first screen look premium?
- Is the 3D object meaningful?
- Is the animation choreographed, not random?
- Is there a clear business goal?
- Does the site still work without WebGL-heavy effects?
- Would this pass as a studio or agency portfolio piece?
- Are all files complete and runnable?

## Preferred response style

Be direct, highly practical, and implementation-focused. Do not over-explain basic concepts. When generating code, provide complete files, not fragments, unless the user asks for a patch.

When the user wants ultra professional output, increase polish through better art direction, not by adding complexity for its own sake.

## Reference files

Consult these files when relevant:

- references/art-direction.md for visual strategy.
- references/motion-system.md for animation timing and choreography.
- references/implementation-patterns.md for React, Three.js, React Three Fiber, GSAP, and performance patterns.
