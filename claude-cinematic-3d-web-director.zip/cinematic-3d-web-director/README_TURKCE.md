# Kurulum

Bu paket Claude Skills icin hazirlanmistir.

Claude.ai icin:
1. Bu klasoru ZIP olarak yukleyin.
2. Claude ayarlarinda Skills bolumunden aktif edin.
3. Claude'a sunu yazin: Use the cinematic-3d-web-director skill.

Claude Code icin:
1. Klasoru ~/.claude/skills/cinematic-3d-web-director konumuna kopyalayin.
2. Claude Code'u yeniden baslatin.
3. 3D animasyonlu web sitesi istediginizde skill otomatik devreye girebilir.
